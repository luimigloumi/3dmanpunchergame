Copyright (c) 2021 Digital Moons
https://digitalmoons.itch.io/

Customer support email: digitalmoonsstudio@gmail.com
Discord: @rrous#3448

--------------------------------


- This free Demo pack contains 6 sky backgrounds in sizes 240 x 135px & FullHD 1920x1080px

- It's a demo for asset pack called Pixel Skies Background pack, which you can find here:
https://digitalmoons.itch.io/pixel-skies


You are allowed to use these Demo backgrounds as a part of your commercial or personal projects if you remember to credit by linking this asset pack somewhere in your game, for example to the game menu, on the website your game/project is on, or to ending credits.

You're not allowed to share, re-sell or redistribute this background pack or any assets/backgrounds/images from it outside from your project in any way or on any platform. You aren't allowed to re-sell or alter and re-sell the images, or otherwise attempt to claim the work as your own.


Link to the asset pack:
https://digitalmoons.itch.io/pixel-skies
--------------------------------
 
If you have any suggestions about how to improve this pack, please leave a comment below the asset on itch.io

Thank you for downloading this pack! 
- Digital Moons